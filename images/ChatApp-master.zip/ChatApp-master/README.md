# ChatApp
Base repo for collective 2-year students' project

## Инструкция
1. **Один** из членов команды делает **"fork"** этого репозитория в своем аккаунте.
2. **Каждый** член команды клонирует форк из п.1 *локально* у себя на ПК во **временную папку**: git clone http://github.com/your_boss_account/ChatApp tmp_dir
3. Каждый создает у себя проект в Eclipse (или другой IDE).
4. Перемещает все содержимое папки tmp_dir в папку с вновь созданным проектом (в том числе скрытые элементы .git и .gitignore!)
5. "Босс" из п.1 дает доступ на запись в свой репозиторий каждому участнику команды (settings->collaborators)

## Далее
Потом - стандартный цикл: git pull - git add - git commit - git push

Как тут: http://rogerdudler.github.io/git-guide/
